package com.example.googlemap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


public class Mypage extends AppCompatActivity {

    EditText input_id;
    EditText input_pass;
    ImageButton button_login;
    ImageButton button_add;
    ImageButton button_company;
    ImageButton button_addCompany;
    Button.OnClickListener clickListener;
    View layer_login;

    String id_log = "Hello";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage);

        input_id = findViewById(R.id.input_id);
        input_pass = findViewById(R.id.input_pass);
        button_login = findViewById(R.id.button_login);
        button_add = findViewById(R.id.button_add);
        button_company = findViewById(R.id.button_company);
        layer_login = findViewById(R.id.layer_login);
        button_addCompany = findViewById(R.id.image_addCompany);


        clickListener = new Button.OnClickListener() {

            @Override
            public void onClick(View view) {
                switch (view.getId()){
                    case R.id.button_login:
                        if(id_log.equals(input_id.getText().toString())){
                            layer_login.setVisibility(View.GONE);
                        }
                        else{
                            Toast.makeText(getApplicationContext(), "나가주세요", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case R.id.button_company:
                        if(layer_login.getVisibility()==View.GONE){
                            button_addCompany.setVisibility(View.VISIBLE);
                        }
                        break;
                }
            }
        };

        button_login.setOnClickListener(clickListener);
        button_add.setOnClickListener(clickListener);
        button_company.setOnClickListener(clickListener);



    }
}