package com.example.googlemap;

public class var {
}
